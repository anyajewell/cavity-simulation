% Code to test tilt and shift operations observed in rotating frame
% CL 10/18/2025

clear all;
clc;
figure;

v = VideoWriter('cavitymode.avi','Motion JPEG AVI');
v.Quality = 95;
open(v);

% Constants
c = 3e8; % [m/s]

% INITIAL CONDITIONS
Lx = 2; % Length of square transverse domain (one side), [m]
Ld = 1064*1e-9; % Laser wavelength, [m]
w0 = 1e-1; % initial beam width, [m]
k0 = (2*pi)/Ld; % wavenumber 
Zmax = 40e3; % destination of z, [m] 
Z0 = -Zmax; % starting location, [m]
t0 = 0; % starting time, [s]
v0 = 0; % starting transverse velocity, [m/s]
L = Zmax - Z0; % cavity length, [m]
Nz = 1e2; % number of steps
dz = L/Nz; % step size, [m]
dt = dz/c; % time step, [s]

% Rotation
Omega = 0.01; % rotational velocity, [rad/sec]
alpha = 0; % rotational acceleration, [rad/sec^2]

% Acceleration
v_perp = 0; % initial transverse velocity, [m/s]
accel = 10000; % transverse acceleration, [m/s^2]
Theta = 0; % initial transverse acceleration tilt, [rad]

% SIMULATION PARAMETERS
N = 511; % sampling number
dx = Lx/N; % step size 

% Create grid
for n=1:N+1 
    for m=1:N+1
        x(m)=(m-1)*dx-Lx/2;
        y(n)=(n-1)*dx-Lx/2;
    end
end
[X,Y] = meshgrid(x,y);


% Gaussian Beam in space domain
Gau_ini = (1/(w0*pi*0.5))*exp(-(X.^2+Y.^2)./(w0^2));

% Beam propagation in inhomogeneous iterative Loop 
Gau = Gau_ini; 
% Centroid locations to begin
centerx(1) = trapz(trapz(X.*abs(Gau).^2))/trapz(trapz(abs(Gau).^2));
centery(1) = trapz(trapz(Y.*abs(Gau).^2))/trapz(trapz(abs(Gau).^2));
% z locations to evaluate field
z = linspace(Z0,Zmax,Nz);

for i = 1:Nz-1

    % MAIN PROPAGATION FUNCTION WILL BE HERE:
    Omega_mid = Omega + 0.5*alpha*dt; % midpoint Omega over the step
  
    v_perp = v_perp + accel*dt; % transverse velocity
    %dx_frame = v_perp*dt; % frame translation this step
    dv = accel*dt; % step in velocity
    Theta = dv/c; % tilt due to transverse acceleration

    % Propagation using angular spectrum method (Schmidt et al.)
    [x2dum, Gau] = ang_spec_prop(Gau,Ld,dx,dx,dz);
    
    % New X-position after trajectory along characteristic curve
    rot_shift = 0.5*Omega_mid/c * (z(i+1).^2-z(i).^2);
    Xnew = X - rot_shift;
    
    % Analytic integration of phase term along characteristic 
    Xint = X*(z(i+1)-z(i)) - 0.5*Omega_mid/c * ...
        (1/3 * (z(i+1).^3-z(i).^3) + 0.5*z(i)*(z(i+1)-z(i)));
    
    % Phase screen implementation for tilt terms
    A = exp(-1i * k0 * Omega_mid / c * Xint); % rotational tilt phase screen
    B = exp(-1i * k0 * Theta.*X); % transverse acceleration tilt phase screen
    Gau = Gau .* A .* B; % apply tilt
    
    % Implementation of shift interpolation
    Gau = interp2(Xnew,Y,Gau,X,Y,'spline'); % interpolate onto the new grid
    
    centerx(i+1) = trapz(trapz(X.*abs(Gau).^2))/trapz(trapz(abs(Gau).^2)); % track center x
    centery(i+1) = trapz(trapz(Y.*abs(Gau).^2))/trapz(trapz(abs(Gau).^2)); % track center y
    
    Omega = Omega + alpha*dt; % advance to next step

    imagesc(x,y,abs(Gau)); axis([-0.5 0.5 -0.5 0.5]); axis square; xlabel('x [m]'); ylabel('y [m]'); 
    hold on; plot(centerx(i+1),centery(i+1),'ro'); hold off; frame = getframe(gcf); display(z(i));
    writeVideo(v,frame);

end

x_rot = -Omega/c * (z.^2 + 0.5*L*z);
x_acc = (v0/c)*(z - Z0) + (accel/(2*c^2))*(z - Z0).^2;
x_ana = x_rot + x_acc; % analytic solution from ray optics

%imagesc(abs(Gau)); title('Beam Profile'); getframe(); display(z(i));

% Plotting
figure;
title({'Displacement in x Over Propagation', '\dOmega = %f', alpha})
plot(centerx,z,'b','DisplayName','Numeric'); hold on;
%plot(x_rot,z,'g','DisplayName','Analytic rotational'); 
plot(x_ana,z,'r','DisplayName','Analytic')
xlabel('Displacement [m]'); ylabel('Distance [m]');
legend();

close(v);


