% function fig = Plot_Center(center, zs)
%     % Plotting
%     fig = figure;
%     plot(center,zs,'b','LineWidth',1.5); hold on;
%     xlabel('Displacement [m]'); ylabel('Distance [m]');
%     title('Beam Center Over Propagation')
% end

function fig = Plot_Center(center, zs)

    fig = figure;
    hold on

    % Color parameter
    t = 1:length(center);

    surface([center; center], ...
            [zs; zs], ...
            [zeros(size(center)); zeros(size(center))], ...
            [t; t], ...
            'facecolor','none', ...
            'edgecolor','interp', ...
            'linewidth',2);

    colormap(turbo)   
    xlabel('Displacement [m]');
    ylabel('Distance [m]');
    title('Beam Center Over Propagation');

    grid on
    box on
end
